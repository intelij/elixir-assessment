defmodule MarineApp.Mailer do
  use Swoosh.Mailer, otp_app: :marine_app
end

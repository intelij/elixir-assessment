defmodule WebSockAdapter.UpgradeError do
  defexception [:message]
end

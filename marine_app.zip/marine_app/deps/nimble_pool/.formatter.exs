# Used by "mix format"
[
  locals_without_parens: [assert_drained: 1],
  inputs: ["{mix,.formatter}.exs", "{config,lib,test}/**/*.{ex,exs}"]
]

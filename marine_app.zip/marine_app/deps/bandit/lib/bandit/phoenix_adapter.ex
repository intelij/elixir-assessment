defmodule Bandit.PhoenixAdapter do
  @moduledoc """
  A Bandit adapter for Phoenix.

  This adapter provides out-of-the-box support for all aspects of Phoenix 1.7 and later. Earlier
  versions of Phoenix will work with this adapter, but without support for WebSockets.

  To use this adapter, your project will need to include Bandit as a dependency:

  ```elixir
  {:bandit, "~> 1.0"}
  ```

  Once Bandit is included as a dependency of your Phoenix project, add the following `adapter:`
  line to your endpoint configuration in `config/config.exs`, as in the following example:

  ```
  # config/config.exs

  config :your_app, YourAppWeb.Endpoint,
    adapter: Bandit.PhoenixAdapter, # <---- ADD THIS LINE
    url: [host: "localhost"],
    render_errors: ...
  ```

  That's it! **After restarting Phoenix you should see the startup message indicate that it is being
  served by Bandit**, and everything should 'just work'. Note that if you have set any exotic
  configuration options within your endpoint, you may need to update that configuration to work
  with Bandit; see below for details.

  ## Endpoint configuration

  This adapter supports the standard Phoenix structure for endpoint configuration. Top-level keys for
  `:http` and `:https` are supported, and configuration values within each of those are interpreted
  as raw Bandit configuration as specified by `t:Bandit.options/0`. Bandit's confguration supports
  all values used in a standard out-of-the-box Phoenix application, so if you haven't made any
  substantial changes to your endpoint configuration things should 'just work' for you.

  In the event that you *have* made advanced changes to your endpoint configuration, you may need
  to update this config to work with Bandit. Consult Bandit's documentation at
  `t:Bandit.options/0` for details.
  """

  @doc """
  Returns the Bandit server proccess for the provided scheme within the given Phoenix Endpoint
  """
  @spec bandit_pid(module()) ::
          {:ok, Supervisor.child() | :restarting | :undefined} | {:error, :no_server_found}
  def bandit_pid(endpoint, scheme \\ :http) do
    endpoint
    |> Supervisor.which_children()
    |> Enum.find(fn {id, _, _, _} -> id == {endpoint, scheme} end)
    |> case do
      {_, pid, _, _} -> {:ok, pid}
      nil -> {:error, :no_server_found}
    end
  end

  @doc """
  Returns the bound address and port of the Bandit server process for the provided
  scheme within the given Phoenix Endpoint
  """
  def server_info(endpoint, scheme) do
    case bandit_pid(endpoint, scheme) do
      {:ok, pid} -> ThousandIsland.listener_info(pid)
      {:error, reason} -> {:error, reason}
    end
  end

  @doc false
  def child_specs(endpoint, config) do
    otp_app = Keyword.fetch!(config, :otp_app)

    plug = resolve_plug(config[:code_reloader], endpoint)

    for scheme <- [:http, :https], opts = config[scheme] do
      opts
      |> Keyword.merge(plug: plug, display_plug: endpoint, scheme: scheme, otp_app: otp_app)
      |> Bandit.child_spec()
      |> Supervisor.child_spec(id: {endpoint, scheme})
    end
  end

  defp resolve_plug(code_reload?, endpoint) do
    if code_reload? &&
         Code.ensure_loaded?(Phoenix.Endpoint.SyncCodeReloadPlug) &&
         function_exported?(Phoenix.Endpoint.SyncCodeReloadPlug, :call, 2) do
      {Phoenix.Endpoint.SyncCodeReloadPlug, {endpoint, []}}
    else
      endpoint
    end
  end
end

# CHANGELOG

## 1.0.4

  * Relax Phoenix.HTML dependency

## 1.0.3

  * Improve error message for invalid file paths

## 1.0.2

  * Improve error message for missing templates

## 1.0.1

  * Add `embed_templates/2` for convenience

## 1.0.0

  * Initial release
